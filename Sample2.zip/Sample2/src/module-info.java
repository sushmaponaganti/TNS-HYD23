/**
 * 
 */
/**
 * 
 */
module Sample2 {
}