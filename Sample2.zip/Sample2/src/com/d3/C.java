package com.d3;

 class C {
int a=5;
static int b=10;
int display() {
	return 10;
}
static void display1(){
System.out.println(10);
}
 }
	
