package com.d3;

 class D {
	public static void main(String[] args) {
		int c=20;
		System.out.println(c);
C a1 = new C();
System.out.println(a1.a);
a1.display();
System.out.println(C.b);
C.display1();
	}

}
