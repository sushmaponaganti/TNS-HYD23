package com.d2;
class B {
	//approach 1
	int a = 5;
	static int b = 10;
	int display(){
		return 10;
	}
static void display1() {
	System.out.println(10);

}
	public static void main(String[] args) {
		B b1 = new B();
				System.out.println(b1.b);
		b1.display(); 
		System.out.println(B.b);
		B.display1();
		}

}
