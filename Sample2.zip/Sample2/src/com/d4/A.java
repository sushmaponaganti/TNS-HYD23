package com.d4;

 class A {
 private void display() {
		System.out.println("TNS Program");

	}

}
