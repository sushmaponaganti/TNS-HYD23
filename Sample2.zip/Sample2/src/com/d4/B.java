package com.d4;
//private access modifier
class B {

	public static void main(String[] args) {
		A obj = new A(); 
 obj.display();
  }
}
	
