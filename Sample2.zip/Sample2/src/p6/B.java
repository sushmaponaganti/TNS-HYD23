package p6;
//public access modifier
import p5.*;
 class B {
public static void main(String[] args) {
	A obj = new A();
	obj.display();
}
}
