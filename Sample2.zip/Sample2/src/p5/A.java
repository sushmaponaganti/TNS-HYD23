package p5;

public class A {

	public void display()
	{
		System.out.println("TNS Program");

	}

}
