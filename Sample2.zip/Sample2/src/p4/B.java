package p4;
import p3.*;
public class B extends A
{
public static void main(String[] args) {
	B obj = new B();
obj.display();
	}

}
